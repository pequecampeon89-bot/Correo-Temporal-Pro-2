# Correo Temporal PRO 2 — Android APK

This project wraps the validated PRO 2 web app in a native Android WebView, preserving the live PRO 2 interface and functionality.

Source URL:
https://lingering-thunder-52c8.amanda-rico-bis.workers.dev/

The APK requires Internet access because it loads the live web application. The web version itself is not modified.

## Build
Use GitHub Actions: upload this project to a GitHub repository, then run **Actions → Build APK**. The resulting `app-debug.apk` is published as a workflow artifact.
